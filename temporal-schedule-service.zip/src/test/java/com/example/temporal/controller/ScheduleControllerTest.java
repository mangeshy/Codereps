package com.example.temporal.controller;

import com.example.temporal.model.ScheduleUpdateRequest;
import com.example.temporal.service.TemporalScheduleService;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.verify;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.patch;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(ScheduleController.class)
class ScheduleControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private TemporalScheduleService scheduleService;

    @Test
    void cancelSchedule_shouldCallService() throws Exception {
        mockMvc.perform(delete("/api/schedules/demo1"))
                .andExpect(status().isOk())
                .andExpect(content().string("Schedule demo1 cancelled successfully."));
        verify(scheduleService).cancelSchedule("demo1");
    }

    @Test
    void amendSchedule_shouldDeserializeAndCallService() throws Exception {
        String json = "{\"intervalSeconds\":3600,\"note\":\"Updated\"}";
        mockMvc.perform(patch("/api/schedules/demo1")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(json))
                .andExpect(status().isOk())
                .andExpect(content().string("Schedule demo1 amended successfully."));

        ArgumentCaptor<ScheduleUpdateRequest> captor = ArgumentCaptor.forClass(ScheduleUpdateRequest.class);
        verify(scheduleService).amendSchedule(org.mockito.ArgumentMatchers.eq("demo1"), captor.capture());
        assertThat(captor.getValue().getNote()).isEqualTo("Updated");
    }
}