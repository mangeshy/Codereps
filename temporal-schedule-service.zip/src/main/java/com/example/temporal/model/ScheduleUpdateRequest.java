package com.example.temporal.model;

import io.temporal.client.schedules.ScheduleCalendarSpec;
import io.temporal.client.schedules.ScheduleIntervalSpec;
import io.temporal.client.schedules.ScheduleSpec;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

public class ScheduleUpdateRequest {

    private Long intervalSeconds;
    private CalendarSpecDto calendarSpec;
    private String note;

    public Long getIntervalSeconds() { return intervalSeconds; }
    public void setIntervalSeconds(Long intervalSeconds) { this.intervalSeconds = intervalSeconds; }
    public CalendarSpecDto getCalendarSpec() { return calendarSpec; }
    public void setCalendarSpec(CalendarSpecDto calendarSpec) { this.calendarSpec = calendarSpec; }
    public String getNote() { return note; }
    public void setNote(String note) { this.note = note; }

    public ScheduleSpec toScheduleSpec(ScheduleSpec existingSpec) {
        ScheduleSpec.Builder builder = existingSpec != null ? existingSpec.toBuilder() : ScheduleSpec.newBuilder();

        if (intervalSeconds != null && intervalSeconds > 0) {
            List<ScheduleIntervalSpec> intervals = new ArrayList<>();
            intervals.add(new ScheduleIntervalSpec(Duration.ofSeconds(intervalSeconds)));
            builder.clearIntervals();
            builder.addAllIntervals(intervals);
        }

        if (calendarSpec != null) {
            builder.clearCalendars();
            builder.addCalendars(calendarSpec.toCalendarSpec());
        }

        return builder.build();
    }

    public static class CalendarSpecDto {
        private List<Integer> daysOfWeek;
        private List<Integer> hours;
        private String comment;
        public List<Integer> getDaysOfWeek() { return daysOfWeek; }
        public void setDaysOfWeek(List<Integer> daysOfWeek) { this.daysOfWeek = daysOfWeek; }
        public List<Integer> getHours() { return hours; }
        public void setHours(List<Integer> hours) { this.hours = hours; }
        public String getComment() { return comment; }
        public void setComment(String comment) { this.comment = comment; }
        public ScheduleCalendarSpec toCalendarSpec() {
            ScheduleCalendarSpec.Builder calBuilder = ScheduleCalendarSpec.newBuilder();
            if (daysOfWeek != null && !daysOfWeek.isEmpty()) calBuilder.addAllDayOfWeek(daysOfWeek);
            if (hours != null && !hours.isEmpty()) calBuilder.addAllHour(hours);
            if (comment != null) calBuilder.setComment(comment);
            return calBuilder.build();
        }
    }
}