package com.example.temporal.service;

import com.example.temporal.model.ScheduleUpdateRequest;
import io.temporal.client.schedules.ScheduleClient;
import io.temporal.client.schedules.ScheduleHandle;
import io.temporal.client.schedules.ScheduleUpdate;
import io.temporal.client.schedules.ScheduleUpdateInput;
import io.temporal.client.schedules.ScheduleSpec;
import org.springframework.stereotype.Service;

@Service
public class TemporalScheduleService {

    private final ScheduleClient scheduleClient;

    public TemporalScheduleService(ScheduleClient scheduleClient) {
        this.scheduleClient = scheduleClient;
    }

    public void cancelSchedule(String scheduleId) {
        ScheduleHandle handle = scheduleClient.getHandle(scheduleId);
        handle.delete();
    }

    public void amendSchedule(String scheduleId, ScheduleUpdateRequest request) {
        ScheduleHandle handle = scheduleClient.getHandle(scheduleId);
        handle.update((ScheduleUpdateInput input) -> {
            ScheduleSpec existingSpec = input.getDescription().getSpec();
            ScheduleSpec newSpec = request.toScheduleSpec(existingSpec);
            ScheduleUpdate.Builder updateBuilder =
                    ScheduleUpdate.newBuilder(input.getDescription()).setSpec(newSpec);
            if (request.getNote() != null && !request.getNote().isBlank()) {
                updateBuilder.setNotes(request.getNote());
            }
            return updateBuilder.build();
        });
    }
}