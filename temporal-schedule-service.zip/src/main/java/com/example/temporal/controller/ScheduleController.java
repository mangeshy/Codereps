package com.example.temporal.controller;

import com.example.temporal.model.ScheduleUpdateRequest;
import com.example.temporal.service.TemporalScheduleService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/schedules")
public class ScheduleController {

    private final TemporalScheduleService scheduleService;

    public ScheduleController(TemporalScheduleService scheduleService) {
        this.scheduleService = scheduleService;
    }

    @DeleteMapping("/{scheduleId}")
    public ResponseEntity<String> cancelSchedule(@PathVariable String scheduleId) {
        scheduleService.cancelSchedule(scheduleId);
        return ResponseEntity.ok("Schedule " + scheduleId + " cancelled successfully.");
    }

    @PatchMapping("/{scheduleId}")
    public ResponseEntity<String> amendSchedule(
            @PathVariable String scheduleId,
            @RequestBody ScheduleUpdateRequest updateRequest) {

        scheduleService.amendSchedule(scheduleId, updateRequest);
        return ResponseEntity.ok("Schedule " + scheduleId + " amended successfully.");
    }
}