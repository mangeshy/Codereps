Temporal Schedule Service (Bazel) - minimal sample
