# Temporal Standing Order - Bazel Example (Java 17 + Spring boot skeleton)

This repository now includes a functional `WORKSPACE` which uses `rules_jvm_external` to fetch Maven artifacts.

How to build & test:
1. Ensure you have Bazel installed (Bazel 6+ recommended).
2. Run `bazel build //...` — this will download Maven dependencies via rules_jvm_external.
3. Run `bazel test //...` to run the unit & integration tests.

Notes:
- The repository pins specific versions. If you need different Spring/Temporal versions, edit `WORKSPACE`.
- If your environment requires Maven credentials or a proxy, configure accordingly.

