package com.example.temporal.standingorder;

import io.temporal.activity.ActivityOptions;
import io.temporal.common.RetryOptions;
import io.temporal.workflow.Workflow;

import java.time.Duration;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Objects;
import java.util.Optional;

public class StandingOrderWorkflowImpl implements StandingOrderWorkflow {
    private final ActivityOptions ao = ActivityOptions.newBuilder()
            .setStartToCloseTimeout(Duration.ofMinutes(5))
            .setScheduleToCloseTimeout(Duration.ofHours(1))
            .setRetryOptions(RetryOptions.newBuilder()
                    .setInitialInterval(Duration.ofSeconds(5))
                    .setMaximumInterval(Duration.ofMinutes(1))
                    .setBackoffCoefficient(2.0)
                    .setMaximumAttempts(5)
                    .build())
            .build();

    private final StandingOrderActivities activities = Workflow.newActivityStub(StandingOrderActivities.class, ao);
    private boolean cancelled = false;

    @Override
    public void cancel() {
        cancelled = true;
    }

    @Override
    public void run(String standingOrderId, LocalDate initialNextExecutionDate) {
        LocalDate nextExecutionDate = initialNextExecutionDate;
        ZoneId zone = ZoneId.of("UTC");

        while (!cancelled) {
            try {
                Optional<LocalDate> persisted = activities.readNextExecutionDate(standingOrderId);
                if (persisted.isPresent()) nextExecutionDate = persisted.get();
            } catch (Exception e) {
                Workflow.getLogger(StandingOrderWorkflowImpl.class).warn("readNextExecutionDate failed: " + e.getMessage());
            }

            LocalDate today = Instant.ofEpochMilli(Workflow.currentTimeMillis()).atZone(zone).toLocalDate();

            if (Objects.equals(nextExecutionDate, today)) {
                try {
                    PaymentPayload payload = activities.fetchPaymentPayload(standingOrderId, nextExecutionDate);
                    activities.publishToKafka(payload);
                    LocalDate newNext = activities.computeAndPersistNextExecutionDate(standingOrderId, nextExecutionDate);
                    if (newNext == null) {
                        Workflow.getLogger(StandingOrderWorkflowImpl.class).info("No nextExecutionDate; completing workflow for " + standingOrderId);
                        break;
                    }
                    nextExecutionDate = newNext;
                } catch (Exception e) {
                    Workflow.getLogger(StandingOrderWorkflowImpl.class).error("Execution failed for " + standingOrderId + ": " + e.getMessage());
                }
            }

            long millisToNextCheck = millisUntilNextCheck(zone);
            Workflow.await(Duration.ofMillis(millisToNextCheck), () -> cancelled);

            if (cancelled) {
                Workflow.getLogger(StandingOrderWorkflowImpl.class).info("Workflow cancelled for " + standingOrderId);
                break;
            }
        }
    }

    private long millisUntilNextCheck(ZoneId zone) {
        var now = Instant.ofEpochMilli(Workflow.currentTimeMillis()).atZone(zone);
        var nextMidnight = now.plusSeconds(86400).toLocalDate().atStartOfDay(zone);
        return java.time.Duration.between(now, nextMidnight).toMillis();
    }
}
