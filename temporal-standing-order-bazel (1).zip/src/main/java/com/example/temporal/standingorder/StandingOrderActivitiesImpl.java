package com.example.temporal.standingorder;

import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.kafka.core.KafkaTemplate;

import java.time.LocalDate;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

@Service
public class StandingOrderActivitiesImpl implements StandingOrderActivities {
    private final WebClient webClient;
    private final KafkaTemplate<String, String> kafkaTemplate;
    private final ConcurrentHashMap<String, LocalDate> persistedNext = new ConcurrentHashMap<>();

    public StandingOrderActivitiesImpl(WebClient.Builder webClientBuilder, KafkaTemplate<String,String> kafkaTemplate) {
        this.webClient = webClientBuilder.build();
        this.kafkaTemplate = kafkaTemplate;
    }

    @Override
    public PaymentPayload fetchPaymentPayload(String standingOrderId, LocalDate executionDate) throws Exception {
        String fakeJson = String.format("{\"standingOrderId\":\"%s\",\"date\":\"%s\",\"amount\":100}", standingOrderId, executionDate);
        return new PaymentPayload(standingOrderId, executionDate, fakeJson);
    }

    @Override
    public void publishToKafka(PaymentPayload payload) throws Exception {
        // in real project use kafkaTemplate.send(...)
        // Here we simulate by printing
        System.out.println("[Kafka] " + payload.getPayloadJson());
    }

    @Override
    public LocalDate computeAndPersistNextExecutionDate(String standingOrderId, LocalDate currentExecutionDate) throws Exception {
        LocalDate next = currentExecutionDate.plusMonths(1);
        persistedNext.put(standingOrderId, next);
        return next;
    }

    @Override
    public Optional<LocalDate> readNextExecutionDate(String standingOrderId) throws Exception {
        return Optional.ofNullable(persistedNext.get(standingOrderId));
    }
}
