package com.example.temporal.standingorder;

import io.temporal.workflow.WorkflowInterface;
import io.temporal.workflow.WorkflowMethod;
import io.temporal.workflow.SignalMethod;

import java.time.LocalDate;

@WorkflowInterface
public interface StandingOrderWorkflow {
    @WorkflowMethod
    void run(String standingOrderId, LocalDate initialNextExecutionDate);

    @SignalMethod
    void cancel();
}
