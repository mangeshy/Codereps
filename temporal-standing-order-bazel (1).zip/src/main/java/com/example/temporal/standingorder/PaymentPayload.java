package com.example.temporal.standingorder;

import java.time.LocalDate;

public class PaymentPayload {
    private final String standingOrderId;
    private final LocalDate executionDate;
    private final String payloadJson;

    public PaymentPayload(String standingOrderId, LocalDate executionDate, String payloadJson) {
        this.standingOrderId = standingOrderId;
        this.executionDate = executionDate;
        this.payloadJson = payloadJson;
    }

    public String getStandingOrderId() { return standingOrderId; }
    public java.time.LocalDate getExecutionDate() { return executionDate; }
    public String getPayloadJson() { return payloadJson; }
}
