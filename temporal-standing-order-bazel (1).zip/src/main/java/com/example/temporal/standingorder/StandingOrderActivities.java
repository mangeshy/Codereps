package com.example.temporal.standingorder;

import io.temporal.activity.ActivityInterface;
import io.temporal.activity.ActivityMethod;

import java.time.LocalDate;
import java.util.Optional;

@ActivityInterface
public interface StandingOrderActivities {
    @ActivityMethod
    PaymentPayload fetchPaymentPayload(String standingOrderId, LocalDate executionDate) throws Exception;

    @ActivityMethod
    void publishToKafka(PaymentPayload payload) throws Exception;

    @ActivityMethod
    LocalDate computeAndPersistNextExecutionDate(String standingOrderId, LocalDate currentExecutionDate) throws Exception;

    @ActivityMethod
    Optional<LocalDate> readNextExecutionDate(String standingOrderId) throws Exception;
}
