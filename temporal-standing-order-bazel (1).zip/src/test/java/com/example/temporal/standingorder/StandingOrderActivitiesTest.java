package com.example.temporal.standingorder;

import org.junit.jupiter.api.Test;
import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.*;

public class StandingOrderActivitiesTest {

    @Test
    public void testFetchPublishPersistFlow() throws Exception {
        StandingOrderActivitiesImpl impl = new StandingOrderActivitiesImpl(org.springframework.web.reactive.function.client.WebClient.builder(), null);
        String so = "SO-UT-1";
        LocalDate today = LocalDate.now();
        PaymentPayload payload = impl.fetchPaymentPayload(so, today);
        assertNotNull(payload);
        assertEquals(so, payload.getStandingOrderId());
        LocalDate next = impl.computeAndPersistNextExecutionDate(so, today);
        assertEquals(today.plusMonths(1), next);
    }
}
