package com.example.temporal.standingorder;

import io.temporal.testing.TestWorkflowEnvironment;
import io.temporal.client.WorkflowClient;
import io.temporal.worker.Worker;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.time.Duration;
import java.time.LocalDate;
import java.time.ZoneOffset;
import java.util.Optional;

import static org.mockito.Mockito.*;

public class StandingOrderWorkflowIntegrationTest {
    private TestWorkflowEnvironment testEnv;

    @BeforeEach
    public void setUp() {
        testEnv = TestWorkflowEnvironment.newInstance();
    }

    @AfterEach
    public void tearDown() {
        if (testEnv != null) testEnv.close();
    }

    @Test
    public void testWorkflowExecutesOnScheduledDate() throws Exception {
        Worker worker = testEnv.newWorker("standing-order-task-queue");
        worker.registerWorkflowImplementationTypes(StandingOrderWorkflowImpl.class);

        StandingOrderActivities mockActivities = Mockito.mock(StandingOrderActivities.class);
        LocalDate todayUtc = LocalDate.now(ZoneOffset.UTC);

        when(mockActivities.readNextExecutionDate("SO-INT-1")).thenReturn(Optional.of(todayUtc));
        when(mockActivities.fetchPaymentPayload("SO-INT-1", todayUtc)).thenReturn(new PaymentPayload("SO-INT-1", todayUtc, "{\"amount\":200}" ));
        when(mockActivities.computeAndPersistNextExecutionDate("SO-INT-1", todayUtc)).thenReturn(todayUtc.plusMonths(1));

        worker.registerActivitiesImplementations(mockActivities);
        testEnv.start();

        WorkflowClient client = testEnv.getWorkflowClient();
        StandingOrderWorkflow wf = client.newWorkflowStub(StandingOrderWorkflow.class,
                io.temporal.client.WorkflowOptions.newBuilder()
                        .setTaskQueue("standing-order-task-queue")
                        .setWorkflowId("so-int-" + java.util.UUID.randomUUID())
                        .build());

        io.temporal.client.WorkflowClient.start(() -> wf.run("SO-INT-1", todayUtc));

        // advance virtual time so timers run
        testEnv.sleep(Duration.ofSeconds(1));

        verify(mockActivities, timeout(2000)).fetchPaymentPayload("SO-INT-1", todayUtc);
        verify(mockActivities, timeout(2000)).publishToKafka(any());
        verify(mockActivities, timeout(2000)).computeAndPersistNextExecutionDate("SO-INT-1", todayUtc);
    }
}
