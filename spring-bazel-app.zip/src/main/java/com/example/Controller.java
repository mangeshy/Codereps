
package com.example;

import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/v1")
public class Controller {

    @GetMapping("/ping")
    public List<String> ping() {
        return List.of("pong");
    }
}
