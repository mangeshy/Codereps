package com.example.scheduler;

import org.junit.jupiter.api.Test;

import java.time.ZoneId;
import java.time.ZonedDateTime;

import static org.junit.jupiter.api.Assertions.*;

class ScheduleControllerTest {

    private final ScheduleController controller = new ScheduleController();

    @Test
    void controllerReturnsOccurrencesJson_likeUnitTest() {
        ZonedDateTime ref = ZonedDateTime.of(2025, 10, 14, 9, 0, 0, 0, ZoneId.of("Europe/London"));
        var resp = controller.nextOccurrences(ref.toString(), "DAILY", 3, null, null, false, "NONE");
        assertEquals(3, resp.occurrences().size());
        assertEquals(ref.plusDays(1), resp.occurrences().get(0));
    }
}
