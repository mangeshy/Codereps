package com.example.scheduler;

import org.junit.jupiter.api.Test;

import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.List;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;

class DstEdgeCasesTest {

    private final QuartzBasedScheduleCalculator calc = new QuartzBasedScheduleCalculator();

    @Test
    void springForward_noExceptions_and_returnsCount() {
        ZoneId zone = ZoneId.of("America/New_York"); // DST rules: spring forward Mar 9, 2025
        ZonedDateTime ref = ZonedDateTime.of(2025, 3, 8, 2, 30, 0, 0, zone); // day before DST jump
        List<ZonedDateTime> out = calc.nextOccurrences(ref, 3, Frequency.DAILY, Set.of(), new HolidayAdjustment.None(), null, false);
        assertEquals(3, out.size());
        assertEquals(zone, out.get(0).getZone());
    }

    @Test
    void fallBack_noExceptions_and_returnsCount() {
        ZoneId zone = ZoneId.of("America/New_York"); // DST rules: fall back Nov 2, 2025
        ZonedDateTime ref = ZonedDateTime.of(2025, 11, 1, 1, 30, 0, 0, zone); // day before DST fall-back
        List<ZonedDateTime> out = calc.nextOccurrences(ref, 3, Frequency.DAILY, Set.of(), new HolidayAdjustment.None(), null, false);
        assertEquals(3, out.size());
        assertEquals(zone, out.get(0).getZone());
    }
}
