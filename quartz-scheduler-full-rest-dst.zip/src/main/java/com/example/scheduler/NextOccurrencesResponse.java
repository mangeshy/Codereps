package com.example.scheduler;

import java.time.ZonedDateTime;
import java.util.List;

public record NextOccurrencesResponse(ZonedDateTime reference, Frequency frequency, List<ZonedDateTime> occurrences) { }
