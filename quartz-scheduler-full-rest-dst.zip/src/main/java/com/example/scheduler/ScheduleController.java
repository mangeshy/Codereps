package com.example.scheduler;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDate;
import java.time.ZonedDateTime;
import java.time.format.DateTimeParseException;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@RestController
public class ScheduleController {

    private final QuartzBasedScheduleCalculator calculator = new QuartzBasedScheduleCalculator();

    @GetMapping("/api/schedule/next")
    public NextOccurrencesResponse nextOccurrences(
            @RequestParam String reference,
            @RequestParam(defaultValue = "DAILY") String frequency,
            @RequestParam(defaultValue = "5") int count,
            @RequestParam(required = false) String holidays, // comma-separated yyyy-MM-dd
            @RequestParam(required = false) String cutoff, // ISO ZonedDateTime
            @RequestParam(defaultValue = "false") boolean includeReference,
            @RequestParam(defaultValue = "NONE") String adjustment
    ) {
        ZonedDateTime refZdt;
        try {
            refZdt = ZonedDateTime.parse(reference);
        } catch (DateTimeParseException ex) {
            throw new IllegalArgumentException("reference must be an ISO zoned date-time, e.g. 2025-10-14T09:00:00+00:00[Europe/London]") ;
        }
        Frequency freq = Frequency.valueOf(frequency.toUpperCase());
        Set<LocalDate> holidaySet = new HashSet<>();
        if (holidays != null && !holidays.isBlank()) {
            holidaySet.addAll(Arrays.stream(holidays.split(","))
                    .map(String::trim)
                    .map(LocalDate::parse)
                    .collect(Collectors.toSet()));
        }
        ZonedDateTime cutoffZ = null;
        if (cutoff != null && !cutoff.isBlank()) {
            cutoffZ = ZonedDateTime.parse(cutoff);
        }
        HolidayAdjustment adj = switch (adjustment.toUpperCase()) {
            case "NEXT" , "NEXTBUSINESSDAY", "NEXT_BUSINESS_DAY" -> new HolidayAdjustment.NextBusinessDay();
            case "PREV", "PREVIOUS", "PREVIOUSBUSINESSDAY", "PREVIOUS_BUSINESS_DAY" -> new HolidayAdjustment.PreviousBusinessDay();
            default -> new HolidayAdjustment.None();
        };
        List<ZonedDateTime> occ = calculator.nextOccurrences(refZdt, count, freq, holidaySet, adj, cutoffZ, includeReference);
        return new NextOccurrencesResponse(refZdt, freq, occ);
    }
}
