package com.example.scheduler;

import java.time.LocalDate;
import java.time.YearMonth;
import java.time.ZonedDateTime;
import java.time.temporal.ChronoUnit;

/**
 * Supported frequencies and helpers.
 */
public enum Frequency {
    DAILY, WEEKLY, BIWEEKLY, MONTHLY, BIMONTHLY, QUARTERLY, YEARLY;

    public LocalDate next(LocalDate reference) {
        return switch (this) {
            case DAILY -> reference.plusDays(1);
            case WEEKLY -> reference.plusWeeks(1);
            case BIWEEKLY -> reference.plusWeeks(2);
            case MONTHLY -> addMonthsPreserveDay(reference, 1);
            case BIMONTHLY -> addMonthsPreserveDay(reference, 2);
            case QUARTERLY -> addMonthsPreserveDay(reference, 3);
            case YEARLY -> reference.plusYears(1);
        };
    }

    private static LocalDate addMonthsPreserveDay(LocalDate d, int months) {
        YearMonth target = YearMonth.from(d).plusMonths(months);
        int day = Math.min(d.getDayOfMonth(), target.lengthOfMonth());
        return LocalDate.of(target.getYear(), target.getMonth(), day);
    }

    public java.time.ZonedDateTime next(java.time.ZonedDateTime reference) {
        return switch (this) {
            case DAILY -> reference.plus(1, ChronoUnit.DAYS);
            case WEEKLY -> reference.plus(1, ChronoUnit.WEEKS);
            case BIWEEKLY -> reference.plus(2, ChronoUnit.WEEKS);
            case MONTHLY -> addMonthsPreserveDay(reference, 1);
            case BIMONTHLY -> addMonthsPreserveDay(reference, 2);
            case QUARTERLY -> addMonthsPreserveDay(reference, 3);
            case YEARLY -> reference.plus(1, ChronoUnit.YEARS);
        };
    }

    private static java.time.ZonedDateTime addMonthsPreserveDay(java.time.ZonedDateTime zdt, int months) {
        YearMonth target = YearMonth.from(zdt).plusMonths(months);
        int day = Math.min(zdt.getDayOfMonth(), target.lengthOfMonth());
        return zdt.withYear(target.getYear()).withMonth(target.getMonthValue()).withDayOfMonth(day);
    }
}
