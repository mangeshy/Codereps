package com.example.scheduler;

import org.quartz.Trigger;
import org.quartz.impl.triggers.CronTriggerImpl;

import java.time.LocalDate;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.Set;

/**
 * Calculator that uses Quartz Trigger APIs where possible to compute next fire times,
 * while falling back to in-house logic for frequencies not expressible via cron.
 *
 * Added API: nextOccurrences(reference, count, frequency, holidays, adjustment, cutoff, includeReference)
 */
public final class QuartzBasedScheduleCalculator {

    public ZonedDateTime next(ZonedDateTime reference, Frequency frequency, Set<LocalDate> holidays, HolidayAdjustment adjustment) {
        Objects.requireNonNull(reference);
        Objects.requireNonNull(frequency);
        Objects.requireNonNull(holidays);
        Objects.requireNonNull(adjustment);

        if (frequency == Frequency.DAILY || frequency == Frequency.WEEKLY || frequency == Frequency.MONTHLY || frequency == Frequency.YEARLY) {
            Trigger trig = buildTriggerForFrequency(reference, frequency);
            Date after = Date.from(reference.toInstant());
            Date candidate = trig.getFireTimeAfter(after);
            int safety = 0;
            while (candidate != null) {
                if (safety++ > 1000) throw new IllegalStateException("Too many iterations computing next date");
                LocalDate candDate = candidate.toInstant().atZone(reference.getZone()).toLocalDate();
                if (holidays.contains(candDate) || HolidayAdjustment.isWeekend(candDate)) {
                    if (adjustment instanceof HolidayAdjustment.None) {
                        candidate = trig.getFireTimeAfter(candidate);
                        continue;
                    } else {
                        LocalDate adjusted = adjustment.adjust(candDate, holidays);
                        return adjusted.atTime(reference.toLocalTime()).atZone(reference.getZone());
                    }
                } else {
                    return ZonedDateTime.ofInstant(candidate.toInstant(), reference.getZone());
                }
            }
            return null;
        } else {
            ZonedDateTime candidate = frequency.next(reference);
            int safety = 0;
            while (true) {
                if (safety++ > 1000) throw new IllegalStateException("Too many iterations computing next date");
                LocalDate candDate = candidate.toLocalDate();
                if (holidays.contains(candDate) || HolidayAdjustment.isWeekend(candDate)) {
                    if (adjustment instanceof HolidayAdjustment.None) {
                        candidate = frequency.next(candidate);
                        continue;
                    } else {
                        LocalDate adjusted = adjustment.adjust(candDate, holidays);
                        return adjusted.atTime(candidate.toLocalTime()).atZone(candidate.getZone());
                    }
                }
                return candidate;
            }
        }
    }

    /**
     * Return up to 'count' next occurrences after 'reference' (optionally including reference).
     * If 'cutoff' is non-null, stop adding occurrences beyond the cutoff (inclusive).
     *
     * If includeReference == true and reference itself is a valid occurrence (not holiday/weekend),
     * it will be included as the first element; otherwise calculation begins after reference.
     */
    public List<ZonedDateTime> nextOccurrences(ZonedDateTime reference, int count, Frequency frequency, Set<LocalDate> holidays, HolidayAdjustment adjustment, ZonedDateTime cutoff, boolean includeReference) {
        Objects.requireNonNull(reference);
        Objects.requireNonNull(frequency);
        Objects.requireNonNull(holidays);
        Objects.requireNonNull(adjustment);
        if (count <= 0) throw new IllegalArgumentException("count must be positive");

        List<ZonedDateTime> out = new ArrayList<>(Math.min(count, 64));
        ZonedDateTime cur = reference;

        if (includeReference) {
            // Check whether reference itself is valid occurrence
            LocalDate refDate = reference.toLocalDate();
            boolean isHolidayOrWeekend = holidays.contains(refDate) || HolidayAdjustment.isWeekend(refDate);
            if (!isHolidayOrWeekend) {
                if (cutoff == null || !reference.isAfter(cutoff)) {
                    out.add(reference);
                }
            } else if (!(adjustment instanceof HolidayAdjustment.None)) {
                LocalDate adjusted = adjustment.adjust(refDate, holidays);
                ZonedDateTime adjustedZ = adjusted.atTime(reference.toLocalTime()).atZone(reference.getZone());
                if (cutoff == null || !adjustedZ.isAfter(cutoff)) {
                    out.add(adjustedZ);
                }
            }
        }

        while (out.size() < count) {
            ZonedDateTime next = next(cur, frequency, holidays, adjustment);
            if (next == null) break;
            if (cutoff != null && next.isAfter(cutoff)) break;
            out.add(next);
            cur = next;
        }
        return out;
    }

    private Trigger buildTriggerForFrequency(ZonedDateTime reference, Frequency freq) {
        int hour = reference.getHour();
        int min = reference.getMinute();
        int sec = reference.getSecond();
        String cron;
        switch (freq) {
            case DAILY -> cron = String.format("%d %d %d ? * *", sec, min, hour);
            case WEEKLY -> cron = String.format("%d %d %d ? * %s", sec, min, hour, reference.getDayOfWeek());
            case MONTHLY -> cron = String.format("%d %d %d %d * ?", sec, min, hour, reference.getDayOfMonth());
            case YEARLY -> cron = String.format("%d %d %d %d %d ?", sec, min, hour, reference.getDayOfMonth(), reference.getMonthValue());
            default -> throw new IllegalArgumentException("Unsupported frequency for cron mapping: " + freq);
        }
        try {
            CronTriggerImpl ct = new CronTriggerImpl();
            ct.setName("calc-trigger-" + System.nanoTime());
            ct.setCronExpression(cron);
            ct.setStartTime(Date.from(reference.minusSeconds(1).toInstant()));
            return ct;
        } catch (org.quartz.SchedulerException | java.text.ParseException e) {
            throw new RuntimeException(e);
        }
    }

    public java.time.LocalDate next(java.time.LocalDate reference, Frequency frequency, Set<java.time.LocalDate> holidays, HolidayAdjustment adjustment) {
        ZonedDateTime z = reference.atStartOfDay(ZoneId.systemDefault());
        ZonedDateTime next = next(z, frequency, holidays, adjustment);
        return next == null ? null : next.toLocalDate();
    }
}
