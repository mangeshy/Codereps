# Quartz-backed Schedule Calculator with REST API & DST Tests

This integrated project includes:
- Core calculator using Quartz where possible
- nextOccurrences API
- Spring Boot REST endpoint at GET /api/schedule/next
- DST edge-case tests for America/New_York

Build & test with Bazel:

```
bazel test //:scheduler_tests
```

Example REST request:

```
GET /api/schedule/next?reference=2025-10-14T09:00:00+00:00[Europe/London]&frequency=DAILY&count=5
```

Holidays may be supplied as comma-separated `yyyy-MM-dd` values.
