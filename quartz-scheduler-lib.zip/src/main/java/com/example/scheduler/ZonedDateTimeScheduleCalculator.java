package com.example.scheduler;

import java.time.LocalDate;
import java.time.ZonedDateTime;
import java.util.Objects;
import java.util.Set;

/**
 * Schedule calculator for ZonedDateTime — preserves time-of-day and zone.
 */
public final class ZonedDateTimeScheduleCalculator implements ScheduleCalculator<ZonedDateTime> {

    @Override
    public ZonedDateTime next(ZonedDateTime reference, Frequency frequency, Set<LocalDate> holidays, HolidayAdjustment adjustment) {
        Objects.requireNonNull(reference, "reference must not be null");
        Objects.requireNonNull(frequency, "frequency must not be null");
        Objects.requireNonNull(holidays, "holidays must not be null");
        Objects.requireNonNull(adjustment, "adjustment must not be null");

        ZonedDateTime candidate = frequency.next(reference);

        int safety = 0;
        while (true) {
            if (safety++ > 1000) throw new IllegalStateException("Too many iterations computing next date");

            LocalDate candDate = candidate.toLocalDate();
            if (holidays.contains(candDate)) {
                if (adjustment instanceof HolidayAdjustment.None) {
                    candidate = frequency.next(candidate);
                    continue;
                } else {
                    LocalDate adjustedDate = adjustment.adjust(candDate, holidays);
                    // keep original time of day and zone
                    candidate = adjustedDate.atTime(candidate.toLocalTime()).atZone(candidate.getZone());
                    if (!holidays.contains(candidate.toLocalDate()) && !HolidayAdjustment.isWeekend(candidate.toLocalDate())) return candidate;
                    continue;
                }
            }

            if (HolidayAdjustment.isWeekend(candDate)) {
                if (adjustment instanceof HolidayAdjustment.None) {
                    candidate = frequency.next(candidate);
                    continue;
                } else {
                    LocalDate adjustedDate = adjustment.adjust(candDate, holidays);
                    candidate = adjustedDate.atTime(candidate.toLocalTime()).atZone(candidate.getZone());
                    if (!holidays.contains(candidate.toLocalDate()) && !HolidayAdjustment.isWeekend(candidate.toLocalDate())) return candidate;
                    continue;
                }
            }

            return candidate;
        }
    }
}
