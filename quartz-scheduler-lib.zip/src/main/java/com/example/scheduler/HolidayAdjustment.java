package com.example.scheduler;

import java.time.LocalDate;

/**
 * Holiday adjustment strategies.
 */
public sealed interface HolidayAdjustment permits HolidayAdjustment.None, HolidayAdjustment.NextBusinessDay, HolidayAdjustment.PreviousBusinessDay {
    LocalDate adjust(LocalDate candidate, java.util.Set<LocalDate> holidays);

    record None() implements HolidayAdjustment {
        @Override public LocalDate adjust(LocalDate candidate, java.util.Set<LocalDate> holidays) {
            // No adjustment -- return candidate as-is (caller will decide to skip if holiday)
            return candidate;
        }
    }

    record NextBusinessDay() implements HolidayAdjustment {
        @Override public LocalDate adjust(LocalDate candidate, java.util.Set<LocalDate> holidays) {
            LocalDate cur = candidate;
            while (isWeekend(cur) || holidays.contains(cur)) {
                cur = cur.plusDays(1);
            }
            return cur;
        }
    }

    record PreviousBusinessDay() implements HolidayAdjustment {
        @Override public LocalDate adjust(LocalDate candidate, java.util.Set<LocalDate> holidays) {
            LocalDate cur = candidate;
            while (isWeekend(cur) || holidays.contains(cur)) {
                cur = cur.minusDays(1);
            }
            return cur;
        }
    }

    static boolean isWeekend(LocalDate d) {
        switch (d.getDayOfWeek()) {
            case SATURDAY, SUNDAY -> { return true; }
            default -> { return false; }
        }
    }
}
