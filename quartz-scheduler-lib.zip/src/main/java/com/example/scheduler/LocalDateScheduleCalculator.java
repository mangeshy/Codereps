package com.example.scheduler;

import java.time.LocalDate;
import java.util.Objects;
import java.util.Set;

/**
 * Schedule calculator for LocalDate.
 */
public final class LocalDateScheduleCalculator implements ScheduleCalculator<LocalDate> {

    @Override
    public LocalDate next(LocalDate reference, Frequency frequency, Set<LocalDate> holidays, HolidayAdjustment adjustment) {
        Objects.requireNonNull(reference, "reference must not be null");
        Objects.requireNonNull(frequency, "frequency must not be null");
        Objects.requireNonNull(holidays, "holidays must not be null");
        Objects.requireNonNull(adjustment, "adjustment must not be null");

        LocalDate candidate = frequency.next(reference);

        // Repeat until we find a non-holiday if adjustment==None or until adjustment yields a business day.
        int safety = 0;
        while (true) {
            if (safety++ > 1000) throw new IllegalStateException("Too many iterations computing next date");

            if (holidays.contains(candidate)) {
                if (adjustment instanceof HolidayAdjustment.None) {
                    // Skip this occurrence and compute next by adding frequency again.
                    candidate = frequency.next(candidate);
                    continue;
                } else {
                    // Adjust to prev/next business day (may still land on holiday/weekend so loop)
                    candidate = adjustment.adjust(candidate, holidays);
                    if (!holidays.contains(candidate) && !HolidayAdjustment.isWeekend(candidate)) return candidate;
                    // otherwise continue loop to handle chained holidays
                    continue;
                }
            }

            // Not a holiday — if weekend, and adjustment==None we treat weekend as business day? Business day logic: weekends are non-business so adjust if needed.
            if (HolidayAdjustment.isWeekend(candidate)) {
                if (adjustment instanceof HolidayAdjustment.None) {
                    // Skip this occurrence and move to next frequency occurrence.
                    candidate = frequency.next(candidate);
                    continue;
                } else {
                    candidate = adjustment.adjust(candidate, holidays);
                    if (!holidays.contains(candidate) && !HolidayAdjustment.isWeekend(candidate)) return candidate;
                    continue;
                }
            }

            return candidate;
        }
    }
}
