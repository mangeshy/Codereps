package com.example.scheduler;

import java.time.LocalDate;
import java.time.ZonedDateTime;
import java.util.Set;

/**
 * Generic schedule calculator.
 * Implementations exist for LocalDate and ZonedDateTime.
 */
public sealed interface ScheduleCalculator<T> permits LocalDateScheduleCalculator, ZonedDateTimeScheduleCalculator {
    /**
     * Compute the next occurrence AFTER the reference date according to frequency, skipping holidays.
     *
     * @param reference the reference instant (exclusive)
     * @param frequency frequency
     * @param holidays set of holiday dates (LocalDate)
     * @param adjustment holiday adjustment strategy
     * @return next occurrence
     */
    T next(T reference, Frequency frequency, Set<LocalDate> holidays, HolidayAdjustment adjustment);
}
