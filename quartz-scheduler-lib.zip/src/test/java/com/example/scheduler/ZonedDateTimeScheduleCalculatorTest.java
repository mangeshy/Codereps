package com.example.scheduler;

import org.junit.jupiter.api.Test;

import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.LocalDate;
import java.time.Month;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;

class ZonedDateTimeScheduleCalculatorTest {

    private final ZonedDateTimeScheduleCalculator calc = new ZonedDateTimeScheduleCalculator();

    @Test
    void preservesTimeAndZone_andAdjustsForHoliday() {
        ZonedDateTime ref = ZonedDateTime.of(2025, 12, 24, 15, 30, 0, 0, ZoneId.of("Europe/London"));
        Set<LocalDate> holidays = Set.of(LocalDate.of(2025, Month.DECEMBER, 25));
        ZonedDateTime next = calc.next(ref, Frequency.DAILY, holidays, new HolidayAdjustment.NextBusinessDay());
        assertEquals(ZonedDateTime.of(2025, 12, 26, 15, 30, 0, 0, ZoneId.of("Europe/London")), next);
    }
}
