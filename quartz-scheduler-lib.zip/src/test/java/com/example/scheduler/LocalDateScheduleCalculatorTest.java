package com.example.scheduler;

import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.time.Month;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;

class LocalDateScheduleCalculatorTest {

    private final LocalDateScheduleCalculator calc = new LocalDateScheduleCalculator();

    @Test
    void dailySkippingHoliday_noneAdjustment() {
        LocalDate ref = LocalDate.of(2025, Month.DECEMBER, 24);
        Set<LocalDate> holidays = Set.of(LocalDate.of(2025, Month.DECEMBER, 25)); // Christmas
        LocalDate next = calc.next(ref, Frequency.DAILY, holidays, new HolidayAdjustment.None());
        // Since 25th is holiday and adjustment NONE -> skip to next frequency occurrence (26th)
        assertEquals(LocalDate.of(2025, Month.DECEMBER, 26), next);
    }

    @Test
    void dailyNextBusinessAdjustment() {
        LocalDate ref = LocalDate.of(2025, Month.DECEMBER, 24); // Wed
        Set<LocalDate> holidays = Set.of(LocalDate.of(2025, Month.DECEMBER, 25)); // Thu
        LocalDate next = calc.next(ref, Frequency.DAILY, holidays, new HolidayAdjustment.NextBusinessDay());
        // 25th is holiday -> adjust to 26th
        assertEquals(LocalDate.of(2025, Month.DECEMBER, 26), next);
    }

    @Test
    void monthlyEndOfMonthPreserveLastDay() {
        LocalDate ref = LocalDate.of(2025, Month.JANUARY, 31);
        Set<LocalDate> holidays = Set.of();
        LocalDate next = calc.next(ref, Frequency.MONTHLY, holidays, new HolidayAdjustment.None());
        // February 2025 has 28 days -> expect 28th Feb
        assertEquals(LocalDate.of(2025, Month.FEBRUARY, 28), next);
    }

    @Test
    void biweekly_handlesConsecutiveHolidays_withPrevAdjustment() {
        LocalDate ref = LocalDate.of(2025, Month.DECEMBER, 1);
        Set<LocalDate> holidays = Set.of(
                LocalDate.of(2025, Month.DECEMBER, 15),
                LocalDate.of(2025, Month.DECEMBER, 16),
                LocalDate.of(2025, Month.DECEMBER, 17)
        );
        LocalDate next = calc.next(ref, Frequency.BIWEEKLY, holidays, new HolidayAdjustment.PreviousBusinessDay());
        // Biweekly from Dec 1 -> Dec 15, but 15-17 are holidays -> previous business day is Dec 14
        assertEquals(LocalDate.of(2025, Month.DECEMBER, 14), next);
    }

    @Test
    void yearly_leapYear() {
        LocalDate ref = LocalDate.of(2019, Month.FEBRUARY, 28);
        Set<LocalDate> holidays = Set.of();
        LocalDate next = calc.next(ref, Frequency.YEARLY, holidays, new HolidayAdjustment.None());
        // Next year 2020 -> Feb 28 + 1 year = 2020-02-28 (not 29th because we keep same day-of-month)
        assertEquals(LocalDate.of(2020, Month.FEBRUARY, 28), next);
    }

    @Test
    void weekendHandling_withNoneAdjustment_skipsToNextFrequency() {
        LocalDate ref = LocalDate.of(2025, Month.MAY, 2); // Friday
        // Weekly -> next is May 9 (Friday) ; to create weekend candidate, use ref as May 1 -> next May 2 (Friday)
        LocalDate r = LocalDate.of(2025, Month.MAY, 3); // Saturday
        LocalDate next = calc.next(r, Frequency.DAILY, Set.of(), new HolidayAdjustment.None());
        // From Saturday + daily -> Sunday (weekend) -> None adjustment => skip to next frequency occurrence (Monday)
        assertEquals(LocalDate.of(2025, Month.MAY, 5), next);
    }
}
