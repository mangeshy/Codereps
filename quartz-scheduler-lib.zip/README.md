# Quartz Schedule Calculator (Java 17)

This library provides simple utilities to compute the **next occurrence** for schedules with frequencies (daily, weekly, biweekly, monthly, bimonthly, quarterly, yearly) while supporting **holiday skipping** and **holiday adjustment strategies** (next business day, previous business day, none).

Although Quartz is a supported dependency (and can be integrated for trigger-based scheduling), the core date calculations use `java.time` for deterministic calculation and easier testing. The reason: Quartz is heavyweight for pure date arithmetic and Quartz Calendars are powerful but integrate into runtime triggers — this library focuses on calculating the *next date* to schedule jobs on, which pairs well with Quartz triggers as needed.

## Features

- Frequencies: daily, weekly, biweekly, monthly, bimonthly, quarterly, yearly.
- Holiday handling: supply a `Set<LocalDate>` for holidays.
- Adjustment strategies: `None`, `NextBusinessDay`, `PreviousBusinessDay`.
- Supports `LocalDate` and `ZonedDateTime` (preserves time-of-day and zone).
- Java 17 features: records, sealed interfaces, switch expressions.
- Bazel build files included.

## Quick start (Bazel)

1. Ensure Bazel is installed.
2. From project root:

```
bazel test //:scheduler_tests
```

Note: `WORKSPACE` uses `rules_jvm_external` to pull dependencies from Maven Central.

## Project layout

```
- src/main/java/com/example/scheduler/  # library sources
- src/test/java/com/example/scheduler/  # tests
- BUILD.bazel
- WORKSPACE
- README.md
```

## Usage example

```java
var calc = new com.example.scheduler.LocalDateScheduleCalculator();
var holidays = java.util.Set.of(java.time.LocalDate.of(2025, 12, 25));
var next = calc.next(java.time.LocalDate.of(2025, 12, 24), com.example.scheduler.Frequency.DAILY, holidays, new com.example.scheduler.HolidayAdjustment.NextBusinessDay());
System.out.println(next); // 2025-12-26
```

## Notes & edge-cases

- Monthly frequency preserves day-of-month where possible; if the next month is shorter the last valid day is used (e.g., Jan 31 -> Feb 28).
- Weekends are considered non-business days when applying `NextBusinessDay` / `PreviousBusinessDay`.
- If `None` is chosen and the calculated date is a holiday or weekend, the library skips that occurrence and computes the next frequency occurrence.

## Tests

Included JUnit 5 tests cover: daily with skipping/adjusting, monthly end-of-month handling, biweekly with consecutive holidays, zoned datetime preservation, leap-year considerations, and weekend handling.

## Extending

- You can add Quartz integration by building a Trigger that uses this calculator's results to schedule job execution and use Quartz Calendars if you prefer.
- The code is intentionally small and focused — feel free to add more complex business-day calendars, regional weekend rules, or integration with external holiday providers.
