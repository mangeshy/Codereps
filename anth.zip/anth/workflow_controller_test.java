package com.example.workflow.controller;

import com.example.workflow.model.ScheduleActionRequest;
import com.example.workflow.model.WorkflowCancellationRequest;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.temporal.client.ScheduleClient;
import io.temporal.client.ScheduleHandle;
import io.temporal.client.WorkflowClient;
import io.temporal.client.WorkflowStub;
import io.temporal.api.common.v1.WorkflowExecution;
import io.temporal.api.workflow.v1.WorkflowExecutionInfo;
import io.temporal.api.workflowservice.v1.ListOpenWorkflowExecutionsResponse;
import io.temporal.serviceclient.WorkflowServiceStubs;
import io.temporal.api.workflowservice.v1.WorkflowServiceGrpc;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Collections;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(WorkflowController.class)
class WorkflowControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @MockBean
    private WorkflowClient workflowClient;

    @MockBean
    private ScheduleClient scheduleClient;

    @MockBean
    private ScheduleHandle scheduleHandle;

    @MockBean
    private WorkflowStub workflowStub;

    @MockBean
    private WorkflowServiceStubs workflowServiceStubs;

    @MockBean
    private WorkflowServiceGrpc.WorkflowServiceBlockingStub blockingStub;

    @BeforeEach
    void setUp() {
        when(scheduleClient.getHandle(anyString())).thenReturn(scheduleHandle);
        when(workflowClient.newUntypedWorkflowStub(anyString())).thenReturn(workflowStub);
        when(workflowClient.newUntypedWorkflowStub(anyString(), anyString()))
            .thenReturn(workflowStub);
    }

    @Test
    void testCancelSchedule_Success() throws Exception {
        String scheduleId = "test-schedule-123";
        ScheduleActionRequest request = new ScheduleActionRequest("CANCEL", "Testing");

        doNothing().when(scheduleHandle).delete();

        mockMvc.perform(post("/api/v1/workflows/schedules/{scheduleId}/action", scheduleId)
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.message").value("Schedule cancelled successfully"))
                .andExpect(jsonPath("$.data").value(scheduleId));

        verify(scheduleHandle, times(1)).delete();
    }

    @Test
    void testPauseSchedule_Success() throws Exception {
        String scheduleId = "test-schedule-456";
        ScheduleActionRequest request = new ScheduleActionRequest("PAUSE", "Maintenance");

        doNothing().when(scheduleHandle).pause(anyString());

        mockMvc.perform(post("/api/v1/workflows/schedules/{scheduleId}/action", scheduleId)
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.message").value("Schedule paused successfully"))
                .andExpect(jsonPath("$.data").value(scheduleId));

        verify(scheduleHandle, times(1)).pause("Maintenance");
    }

    @Test
    void testUnpauseSchedule_Success() throws Exception {
        String scheduleId = "test-schedule-789";
        ScheduleActionRequest request = new ScheduleActionRequest("UNPAUSE", "Resume");

        doNothing().when(scheduleHandle).unpause(anyString());

        mockMvc.perform(post("/api/v1/workflows/schedules/{scheduleId}/action", scheduleId)
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.message").value("Schedule unpaused successfully"));

        verify(scheduleHandle, times(1)).unpause("Resume");
    }

    @Test
    void testScheduleAction_InvalidAction() throws Exception {
        String scheduleId = "test-schedule-999";
        ScheduleActionRequest request = new ScheduleActionRequest("INVALID", "Test");

        mockMvc.perform(post("/api/v1/workflows/schedules/{scheduleId}/action", scheduleId)
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.success").value(false))
                .andExpect(jsonPath("$.error").value("Invalid action. Supported: CANCEL, PAUSE, UNPAUSE"));

        verify(scheduleHandle, never()).delete();
        verify(scheduleHandle, never()).pause(anyString());
        verify(scheduleHandle, never()).unpause(anyString());
    }

    @Test
    void testScheduleAction_Exception() throws Exception {
        String scheduleId = "test-schedule-error";
        ScheduleActionRequest request = new ScheduleActionRequest("CANCEL", "Test");

        doThrow(new RuntimeException("Schedule not found"))
            .when(scheduleHandle).delete();

        mockMvc.perform(post("/api/v1/workflows/schedules/{scheduleId}/action", scheduleId)
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isInternalServerError())
                .andExpect(jsonPath("$.success").value(false))
                .andExpect(jsonPath("$.error").value("Failed to perform action: Schedule not found"));
    }

    @Test
    void testCancelWorkflow_Success() throws Exception {
        String workflowId = "test-workflow-123";
        WorkflowCancellationRequest request = new WorkflowCancellationRequest(null, "Test cancellation");

        doNothing().when(workflowStub).cancel();

        mockMvc.perform(delete("/api/v1/workflows/workflows/{workflowId}", workflowId)
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.message").value("Workflow cancelled successfully"))
                .andExpect(jsonPath("$.data").value(workflowId));

        verify(workflowStub, times(1)).cancel();
    }

    @Test
    void testCancelWorkflow_WithRunId() throws Exception {
        String workflowId = "test-workflow-456";
        String runId = "run-123";
        WorkflowCancellationRequest request = new WorkflowCancellationRequest(runId, "Cancel");

        doNothing().when(workflowStub).cancel();

        mockMvc.perform(delete("/api/v1/workflows/workflows/{workflowId}", workflowId)
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true));

        verify(workflowClient, times(1)).newUntypedWorkflowStub(workflowId, runId);
        verify(workflowStub, times(1)).cancel();
    }

    @Test
    void testCancelWorkflow_NoRequestBody() throws Exception {
        String workflowId = "test-workflow-789";

        doNothing().when(workflowStub).cancel();

        mockMvc.perform(delete("/api/v1/workflows/workflows/{workflowId}", workflowId)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true));

        verify(workflowStub, times(1)).cancel();
    }

    @Test
    void testCancelWorkflow_Exception() throws Exception {
        String workflowId = "test-workflow-error";

        doThrow(new RuntimeException("Workflow not found"))
            .when(workflowStub).cancel();

        mockMvc.perform(delete("/api/v1/workflows/workflows/{workflowId}", workflowId)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isInternalServerError())
                .andExpect(jsonPath("$.success").value(false))
                .andExpect(jsonPath("$.error").value("Failed to cancel workflow: Workflow not found"));
    }

    @Test
    void testGetRunningWorkflows_Success() throws Exception {
        when(workflowClient.getWorkflowServiceStubs()).thenReturn(workflowServiceStubs);
        when(workflowServiceStubs.blockingStub()).thenReturn(blockingStub);
        when(workflowClient.getOptions()).thenReturn(
            WorkflowClient.newOptions().setNamespace("default").build()
        );

        WorkflowExecution execution = WorkflowExecution.newBuilder()
            .setWorkflowId("workflow-1")
            .setRunId("run-1")
            .build();

        WorkflowExecutionInfo executionInfo = WorkflowExecutionInfo.newBuilder()
            .setExecution(execution)
            .setType(io.temporal.api.common.v1.WorkflowType.newBuilder()
                .setName("TestWorkflow")
                .build())
            .setStartTime(com.google.protobuf.Timestamp.newBuilder()
                .setSeconds(System.currentTimeMillis() / 1000)
                .build())
            .setStatus(io.temporal.api.enums.v1.WorkflowExecutionStatus.WORKFLOW_EXECUTION_STATUS_RUNNING)
            .build();

        ListOpenWorkflowExecutionsResponse response = ListOpenWorkflowExecutionsResponse.newBuilder()
            .addExecutions(executionInfo)
            .build();

        when(blockingStub.listOpenWorkflowExecutions(any()))
            .thenReturn(response);

        mockMvc.perform(get("/api/v1/workflows/workflows/running")
                .param("maxResults", "100"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.message").value("Retrieved running workflows"))
                .andExpect(jsonPath("$.data").isArray())
                .andExpect(jsonPath("$.data[0].workflowId").value("workflow-1"))
                .andExpect(jsonPath("$.data[0].runId").value("run-1"))
                .andExpect(jsonPath("$.data[0].workflowType").value("TestWorkflow"));
    }

    @Test
    void testGetRunningWorkflows_Exception() throws Exception {
        when(workflowClient.getWorkflowServiceStubs()).thenReturn(workflowServiceStubs);
        when(workflowServiceStubs.blockingStub()).thenReturn(blockingStub);
        when(workflowClient.getOptions()).thenReturn(
            WorkflowClient.newOptions().setNamespace("default").build()
        );

        when(blockingStub.listOpenWorkflowExecutions(any()))
            .thenThrow(new RuntimeException("Service unavailable"));

        mockMvc.perform(get("/api/v1/workflows/workflows/running"))
                .andExpect(status().isInternalServerError())
                .andExpect(jsonPath("$.success").value(false))
                .andExpect(jsonPath("$.error").value("Failed to retrieve workflows: Service unavailable"));
    }
}