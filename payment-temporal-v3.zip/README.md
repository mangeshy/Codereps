
# Payment Temporal – v3

## Key Change
Grouping no longer uses Temporal signals.

Instead, an **External Grouping Accumulator Service** collects transaction readiness
events and forms groups once all transactions from a file have a group assigned.

## IsGroupReady Rule
A file is considered group‑ready when:

> All transactions in the file have a group associated with them.

No workflow signals are required.

---

## Architecture

1. File Ingestion Workflow
2. Transaction Workflows
3. External Grouping Accumulator Service
4. Group Approval Workflow
5. Multi‑Level Approval UI (React)
6. Event Sourcing Ledger
7. MongoDB Persistence

---

## Grouping Flow

Transaction Workflow → emits readiness event → Accumulator → assigns group →
starts Group Workflow → waits for approvals → signals transactions (activity call).

---

## Build

```bash
bazel build //...
docker compose up
```

---
