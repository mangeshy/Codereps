
package com.payment.grouping;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class GroupingAccumulatorService {

    private final Map<String, Set<String>> fileTransactions = new ConcurrentHashMap<>();
    private final Map<String, Set<String>> groupedTransactions = new ConcurrentHashMap<>();

    public void registerTransaction(String fileId, String transactionId) {
        fileTransactions
            .computeIfAbsent(fileId, k -> new HashSet<>())
            .add(transactionId);
    }

    public void markGrouped(String fileId, String transactionId) {
        groupedTransactions
            .computeIfAbsent(fileId, k -> new HashSet<>())
            .add(transactionId);
    }

    public boolean isGroupReady(String fileId) {
        return groupedTransactions.containsKey(fileId) &&
               groupedTransactions.get(fileId).size() ==
               fileTransactions.get(fileId).size();
    }
}
