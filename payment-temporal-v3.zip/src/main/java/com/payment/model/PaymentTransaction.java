
package com.payment.model;

import java.math.BigDecimal;

public record PaymentTransaction(
        String transactionId,
        String fileId,
        String accountNumber,
        String currency,
        BigDecimal amount,
        String groupId,
        String status
) {}
