
package com.payment.workflow;

import io.temporal.activity.ActivityInterface;

@ActivityInterface
public interface GroupingActivities {

    void notifyTransactionReady(String transactionId, String fileId);
}
