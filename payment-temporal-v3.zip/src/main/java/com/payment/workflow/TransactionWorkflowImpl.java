
package com.payment.workflow;

import io.temporal.workflow.Workflow;

public class TransactionWorkflowImpl implements TransactionWorkflow {

    @Override
    public void processTransaction(String transactionId, String fileId) {

        // Simulate processing
        Workflow.sleep(2000);

        // Emit readiness event to external accumulator (activity call)
        GroupingActivities activities =
                Workflow.newActivityStub(GroupingActivities.class);

        activities.notifyTransactionReady(transactionId, fileId);
    }
}
